using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockCount : MonoBehaviour
{

    bool isCheck = true;
    int dd = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        //dd = GiveElement.Instance.CurBlockColor;

        //if (dd == 1)
        //{
        //    Debug.Log("White");
      
        //}
        //if (dd == 2)
        //{
        //    Debug.Log("Red");

        //}
        //if (dd == 3)
        //{
        //    Debug.Log("Blue");

        //}
        //if (dd == 4)
        //{
        //    Debug.Log("Green");

        //}
        //if (dd == 5)
        //{
        //    Debug.Log("Purple");

        //}

    }

    void SpecialBlock()
    {

        


    }
}
